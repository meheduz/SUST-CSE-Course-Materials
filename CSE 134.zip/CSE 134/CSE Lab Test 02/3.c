
#include <stdio.h>

int main() {
    int d, t;
    float v;

    scanf("%d %d", &d, &t);

    v = (d / 1000.0) / (t / 3600.0);

    
    printf("%.1f km/h\n", v);

    if (v < 60) {
        printf("Too slow. Needs more changes.\n");
    } else if (v >= 60 && v < 90) {
        printf("Velocity is okay. The car is ready!\n");
    } else {
        printf("Too fast. Only a few changes should suffice.\n");
    }

    return 0;
}