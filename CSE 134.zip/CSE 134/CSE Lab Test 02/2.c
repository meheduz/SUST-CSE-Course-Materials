
#include <stdio.h>

int binaryToDecimal(long long binary);
int decimalToOctal(int decimal);

int main() {
    long long binary;
    int decimal, octal;

    scanf("%lld", &binary);

    decimal = binaryToDecimal(binary);
    octal = decimalToOctal(decimal);

    printf("%d\n", octal);

    return 0;
}

int binaryToDecimal(long long binary) {
    int decimal = 0, b = 1, r;

    while (binary != 0) {
        r = binary % 10;
        binary /= 10;
        decimal += r * b;
        b *= 2;
    }

    return decimal;
}

int decimalToOctal(int decimal) {
    int octal = 0, b = 1;

    while (decimal != 0) {
        octal += (decimal % 8) * b;
        decimal /= 8;
        b*= 10;
    }

    return octal;
}