#include <stdio.h>

int main() {
    int mark, c = 0;
    int max = -1, min = 101, sum = 0;

    while (1) {
        scanf("%d", &mark);

        if (mark < 0 || mark > 100) {
            break;
        }

        if (mark > max) {
            max = mark;
        }

        if (mark < min) {
            min = mark;
        }

        sum += mark;
        c++;
    }

    if (c > 0) {
        printf("Max= %d & Min= %d & AVG = %.2f\n", max, min, (float)sum / c);
    } else {
        printf("Invalid mark.\n");
    }

    return 0;
}