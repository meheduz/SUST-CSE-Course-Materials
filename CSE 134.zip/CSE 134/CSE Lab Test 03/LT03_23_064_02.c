#include<stdio.h>
#include<string.h>
int main() {
    char str[100];
    scanf("%s", str);

    int len = strlen(str);
    for(int i = 0; i < len; i++) {
        if(str[i] >= 'a' && str[i] <= 'z') {
            if(str[i] == 'z') {
                str[i] = 'a';
            } else {
                str[i] = str[i] + 1;
            }
        } else if(str[i] >= 'A' && str[i] <= 'Z') {
            if(str[i] == 'Z') {
                str[i] = 'A';
            } else {
                str[i] = str[i] + 1;
            }
        }
    }

    printf("%s\n", str);

    return 0;
}