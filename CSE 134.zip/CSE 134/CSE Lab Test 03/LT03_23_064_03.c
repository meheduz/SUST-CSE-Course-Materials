#include<stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int arr1[n], arr2[n];
    for(int i = 0; i < n; i++) scanf("%d", &arr1[i]);
    for(int i = 0; i < n; i++) scanf("%d", &arr2[i]);
    int temp[2 * n], k = 0;
    for(int i = 0; i < n; i++) temp[k++] = arr1[i];
    for(int i = 0; i < n; i++) temp[k++] = arr2[i];

    int unique[k], uniqueSize = 0;

    for(int i = 0; i < k; i++) {
        int isUnique = 1;
        for(int j = 0; j < uniqueSize; j++) {
            if(temp[i] == unique[j]) {
                isUnique = 0;
                break;
            }
        }
        if(isUnique) unique[uniqueSize++] = temp[i];
    }

    for(int i = 0; i < uniqueSize; i++) printf("%d ", unique[i]);
    printf("\n");

    return 0;
}