#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int y;
    scanf("%d",&y);
    for(int i=0;i<y/2;i++){
        int new=a[i];
        a[i]=a[y-i-1];
        a[y-i-1]=new;
    }
    printf("{%d,",a[0]);
    for(int i = 1;i<n-1;i++){
        printf("%d,",a[i]);
    }
    printf("%d}",a[n-1]);
    return 0;
}