
#include<stdio.h>
struct Addres{

char village[15];
char upazilla[15];
char zilla[15];
char division[15];

};

struct Blood{

char group[3];
int availability;
char date[12];
};

struct Student{

char name[15];
int age;
int total_mark;
struct Addres sadr;
};

void printAddres(struct Addres ad);
void printDetails(struct Student std);

void main(){
struct Student stds[5]= {{"sifat", 27, 88,{"Mirpur", "Mirpur Sadar", "Dhaka", "Dhaka"}},
                        {"rahul", 25, 90, {"Rajbari", "Rajbari Sadar", "Rajbari", "Dhaka"}},
                        {"amina", 30, 85,{"Shibganj", "Shibganj", "Chapainawabganj", "Rajshahi"}},
                        {"karim", 28, 92,{"Dhanbari", "Dhanbari", "Tangail", "Dhaka"}},
                        {"lina", 26, 87,{"Kaliganj", "Kaliganj", "Jhenidah", "Khulna"}}};

int sum = 0;
for(int i = 0;i<5;i++){

    sum += stds[i].total_mark;

}

printf("Avg mark is: %0.2f",sum/5.0);

int max = stds[0].total_mark,max_index = 1;

for(int i = 1; i<5;i++){

    if(stds[i].total_mark > max)
    {
        max  = stds[i].total_mark;
        max_index = i+1;
    }
}

printf("\nHighest mark is: %d got by %s",max,stds[max_index-1]);


char search[15];
printf("\nEnter a name to look into his age and total mark:");
scanf("%s",search);

int found = 0;
for(int i = 0;i <5;i++){

    if(strcmp(stds[i].name,search)==0){
        printf("\n%s is %d years young and got %d marks",search,stds[i].age,stds[i].total_mark);
        found = 1;
        printAddres(stds[i].sadr);
        break;
    }
}

if(!found)
    printf("Not found! This person doesn't exists in out database");

int sr_age;
printf("\nEnter search age:");
scanf("%d",&sr_age);
printf("Students who are older than %d age\n",sr_age);
for(int i = 0;i<5;i++){

    if(stds[i].age > sr_age){
        printDetails(stds[i]);
    }
}
int extra_mark;
printf("\nEnter amount of extra marks:");
scanf("%d",&extra_mark);

for(int i = 0;i<5;i++)
     if(strcmp(stds[i].name,search)==0)
            stds[i].total_mark += extra_mark;

for(int i = 0;i<5;i++)
    printDetails(stds[i]);

}

void printDetails(struct Student std){

 printf("Name: %s\nAge: %d\nTotal Mark: %d\n",std.name,std.age,std.total_mark);

}

void printAddres(struct Addres ad){

 printf("Village: %s\tUpazilla: %s\tZilla: %s\tDivision: %s\t",ad.village,ad.upazilla,ad.zilla,ad.division);

}
