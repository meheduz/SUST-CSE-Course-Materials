#include<stdio.h>
struct Date{
    
int day;
int month;
int year;
char BAR[10];

};

struct Blood{

char group[3];
int availability;
struct Date date;
};

struct Donor {
    char name[10];
    int age;
    struct Blood bld;
};


void main(){

struct Donor dl[3] = {
{"sifat",27, {"A+",1, {16,2,2025,"Sunday"}   } },
{"rifat",25, {"A-",0, {26,2,2024,"Saturday"}   } },
{"rafat",2, {"A-",0, {10,12,2021,"Monday"}   }},
};


for (int i = 0; i < 3 ;i++){
    printf("%d th Donor's Data:\n",i+1);
    printf("--------------------------------\n");
    printf("Name: %s\tAge: %d\n",dl[i].name,dl[i].age);

    printf("Blood Group: %s\tAvailability: %s\n",dl[i].bld.group,(dl[i].bld.availability)? "Available" : "Not Available");
    printf("Date: (%d-%d-%d)\tBar: %s",
           dl[i].bld.date.day,dl[i].bld.date.month,dl[i].bld.date.year,dl[i].bld.date.BAR);
    printf("\n");

}

}





