
#include<stdio.h>
#include<math.h>
struct Point{

int x;
int y;

};
 struct Point add(struct Point a,struct Point b){

     struct Point c;   /// c = a + b;
     c.x = a.x + b.x;
     c.y = a.y + b.y;
     return c;
 }

  struct Point sub(struct Point a,struct Point b){

     struct Point c;   /// c = a + b;
     c.x = a.x - b.x;
     c.y = a.y - b.y;
     return c;
 }
   float mod(struct Point a){ /// | |

     float m = sqrt((a.x*a.x) + (a.y*a.y));
     return m;
 }

  float distance(struct Point a,struct Point b){ /// | |    code   "project euler"

     return  sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));

 }
void main(){

struct Point p1,p2;

printf("Enter 1st Point (x,y)");
scanf("%d%d",&p1.x,&p1.y);

printf("Enter 2nd Point (x,y)");
scanf("%d%d",&p2.x,&p2.y);

printf("1.Add\n2.Sub\n3.Distance\n4.Modulus\n");
int choice;
scanf("%d",&choice);

struct Point result;
float rz;
switch(choice){

case 1: { result = add(p1,p2);  break;}
case 2: { result = sub(p1,p2);  break;}
case 3: { rz = distance(p1,p2);  break;}
case 4: { rz = mod(p1);  break;}
};

if(choice <=2)
printf("Resultant Point is (%d,%d)\n",result.x,result.y);
else if (choice <=4)
printf("Result : %f",rz);




}

