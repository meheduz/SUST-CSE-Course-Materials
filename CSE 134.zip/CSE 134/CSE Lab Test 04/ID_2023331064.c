#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUBJECTS 5
#define MAX_STUDENTS 100

struct Student {
    char name[50];
    int id;
    float cgpa;
    int marks[SUBJECTS];
    char grade;
    int classGroup;
};

char GradeCalc(float avg) {
    if (avg >= 90) return 'A';
    else if (avg >= 80) return 'B';
    else if (avg >= 70) return 'C';
    else if (avg >= 60) return 'D';
    else return 'F';
}

int ClassCalc(float cgpa) {
    if (cgpa >= 3.75) return 1;
    else if (cgpa >= 3.30) return 2;
    else if (cgpa >= 3.00) return 3;
    else return 4;
}

int main() {
    struct Student students[MAX_STUDENTS];
    int N;

    FILE *input = fopen("input.txt", "r");
    if (!input) {
        printf("Could not open input.txt\n");
        return 1;
    }

    fscanf(input, "%d", &N);
    for (int i = 0; i < N; i++) {
        fscanf(input, "%s %d %f", students[i].name, &students[i].id, &students[i].cgpa);
        float total = 0;
        for (int j = 0; j < SUBJECTS; j++) {
            fscanf(input, "%d", &students[i].marks[j]);
            total += students[i].marks[j];
        }
        float avg = total / SUBJECTS;
        students[i].grade = GradeCalc(avg);
        students[i].classGroup = ClassCalc(students[i].cgpa);
    }
    fclose(input);
    
    FILE *output = fopen("output.txt", "w");
    if (!output) {
        printf("Could not open output.txt\n");
        return 1;
    }

    for (int i = 0; i < N; i++) {
        fprintf(output, "%s %d %.2f ", students[i].name, students[i].id, students[i].cgpa);
        for (int j = 0; j < SUBJECTS; j++) {
            fprintf(output, "%d ", students[i].marks[j]);
        }
        fprintf(output, "%c %d\n", students[i].grade, students[i].classGroup);
    }
    char *subjects[] = {"PHY", "CHEM", "MATH", "BIO", "ENG"};
    for (int s = 0; s < SUBJECTS; s++) {
        int high = -1, low = 101;
        int high_id = -1, low_id = -1;
        char high_name[50], low_name[50];
        for (int i = 0; i < N; i++) {
            if (students[i].marks[s] > high) {
                high = students[i].marks[s];
                high_id = students[i].id;
                strcpy(high_name, students[i].name);
            }
            if (students[i].marks[s] < low) {
                low = students[i].marks[s];
                low_id = students[i].id;
                strcpy(low_name, students[i].name);
            }
        }
        printf("%s Highest: %d by %s %d\n", subjects[s], high, high_name, high_id);
        printf("%s Lowest: %d by %s %d\n", subjects[s], low, low_name, low_id);
    }

    fclose(output);
    return 0;
}