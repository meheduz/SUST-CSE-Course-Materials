/*
 find the area of equilateral triangle, given value of one side "a".
*/
#include<stdio.h>
#include<math.h>
void main(){

int a;

printf("Enter value of side : ");
scanf("%d",&a);

float  d = sqrt(3)/4*a*a;


printf("Area is %5.3f",d);






}

