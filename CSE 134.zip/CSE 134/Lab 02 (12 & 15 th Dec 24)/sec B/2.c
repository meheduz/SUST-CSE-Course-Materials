/*
find out whether a point falls inside or outside of a ellipse  where the equation is (x+2)^2/16 + (y-1)^2/5 = 1
without using if-else

sample input       sample out
(-2,1)             Inside
(2,1)              Inside
(10,20)            Outside
*/
#include<stdio.h>

void main(){

int x,y;

printf("Enter values like (x,y): ");
scanf("%d%d",&x,&y);

float  d = (x+2)*(x+2)/16.0 + (y-1)*(y-1)/5.0;

// (d <= 1) ? printf("Inside") : printf("Outside");

(d < 1) ? printf("Inside") : ((d ==  1) ? printf("Over") : printf("Outside")); //  nested ternary operator






}
