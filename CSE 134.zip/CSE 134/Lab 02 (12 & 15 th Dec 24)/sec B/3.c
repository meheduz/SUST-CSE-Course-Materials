/*
find the force between two masses m1,m2 which are in d meter distance. G = 6.673_10^-11
*/
#include<stdio.h>

void main(){


double m1,m2,d,F;

printf("Enter masses like (m1,m2): ");
scanf("%lf%lf",&m1,&m2);

printf("Enter distance like d: ");
scanf("%lf",&d);

F = (6.673e-11)* (m1*m2)/(d*d);

printf("Newtonian Force : %.25lf",F);






}

