/*
Given two vectors (x,y) , find dot products. for example  P.Q = (x1*x2 + y1*y2)
where P= (x1,x2) , Q = (x2,y2)


sample input       sample out
(1,2) (3,4)        Dot Product : 11
(5,6) (7,8)        Dot Product : 83
*/
#include<stdio.h>

void main(){

int x1,y1,x2,y2;

printf("Enter 1st Vector like (x,y): ");
scanf("%d%d",&x1,&y1);

printf("Enter 2nd Vector like (x,y): ");
scanf("%d%d",&x2,&y2);

int dotP = x1*x2 + y1*y2;

printf("%d",dotP);





}
