/*
test whether a number 'n' falls under this range (a,b] where a,b, n will be given as input from user

[a,b)  == [a,b[
(a,b]  == ]a,b]
(a,b)  == ]a,b[
*/
#include<stdio.h>

void main(){

int n,s,e;

printf("Enter start and end of the range: ");
scanf("%d%d",&s,&e);

printf("Enter the number: ");
scanf("%d",&n);

((s < n ) && (n <= e)) ? printf("Inside!") : printf("Outside!!!") ;
}
