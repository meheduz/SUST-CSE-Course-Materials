/*
given the equation (x-5)^2 + (y-9)^2 = 100 , find out whether a cartesian points falls inside or not. [without using if else]

(15,6) -> not inside
(6,10), (5,9) -> inside
*/
#include<stdio.h>
void main(){

int x,y;

printf("Enter point as x and y");
scanf("%d%d",&x,&y);

((x-5)*(x-5) + (y-9)*(y-9)<= 100) ? printf("Inside") : printf("Outside");


}

