/*
given two cartesian points , find out the slope.
(12-7)/(10-8) = 5.0/2= 2.5

(8,7) (10,12)
*/
#include<stdio.h>
void main(){

int x1,x2,y1,y2;

printf("Enter first point as x and y");
scanf("%d%d",&x1,&y1);

printf("Enter second point as x and y");
scanf("%d%d",&x2,&y2);

float slope = (float)(y1-y2)/(x1-x2);

printf("Desired slope is %f",slope);



}

