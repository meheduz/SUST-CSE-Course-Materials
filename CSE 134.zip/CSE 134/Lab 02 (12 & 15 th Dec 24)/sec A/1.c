/*
write a program to find out the area of a trapezoid.
*/
#include<stdio.h>
void main(){

float a,b,h,area;

printf("Enter two parallel sides: ");
scanf("%f%f",&a,&b);

printf("Enter height between: ");
scanf("%f",&h);

area = 0.5*(a+b)*h;

printf("Desired Area of Trapezoid: %0.2f",area);

}
