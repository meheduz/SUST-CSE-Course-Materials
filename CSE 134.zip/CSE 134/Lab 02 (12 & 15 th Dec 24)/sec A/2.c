/*
write a program to find out (say "inside" or "outside") whether a given number in between a range or not.you will take 3 numbers ,
first two are range values, 3rd value is the value needed to be tested in between the given range(inclusive)[ without using if-else)
---------------------------------------------- OR -------------------------------------------------------
test whether a number 'n' falls under this range [a,b] where a,b, n will be given as input from user

[a,b)  == [a,b[
(a,b]  == ]a,b]
(a,b)  == ]a,b[
*/
#include<stdio.h>
void main(){

int start,end,num;

printf("Enter range values then the testing number");

scanf("%d%d%d",&start,&end,&num);

(start<=num && num<= end) ? printf("inside") : printf("outside");



}

