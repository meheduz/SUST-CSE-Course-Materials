#include <stdio.h>
#include <math.h>

int main() {
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    double d = b * b - 4 * a * c;
    (d < 0) ? printf("Imaginary Roots!") : printf("%.2lf %.2lf", (-b + sqrt(d)) / (2 * a), (-b - sqrt(d)) / (2 * a));
    return 0;
}