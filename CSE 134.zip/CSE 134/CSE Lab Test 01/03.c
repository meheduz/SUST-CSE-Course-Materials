#include <stdio.h>
#include <math.h>

int main() {
    float u1, u2, v1, v2;
    const float Pi = 3.14159;

    printf("Enter the x and y components of vector u: ");
    scanf("%f %f", &u1, &u2);

    printf("Enter the x and y components of vector v: ");
    scanf("%f %f", &v1, &v2);


    float dotP = u1 * v1 + u2 * v2;


    float magnitude_u = sqrt(u1 * u1 + u2 * u2);
    float magnitude_v = sqrt(v1 * v1 + v2 * v2);


    float theta = acos(dotP / (magnitude_u * magnitude_v));

    float degree = theta * 180.0 / Pi;

    printf("%.2f degrees", degree);

    return 0;
}