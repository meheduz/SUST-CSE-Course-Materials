#include <stdio.h>
int main(){
    int a,b,c;
    scanf("%d %d %d",&a, &b, &c);
    (a == b == c )? printf("euailateral") : (a == b || b == c || a == c) ? printf("isoceles") : printf("scalene");
    return 0;
}
