/* find wheter a triangle valid or invalid*/
#include<stdio.h>

void main(){

int a,b,c;

printf("enter 3 sides of a triangle: ");
scanf("%d%d%d",&a,&b,&c);

((a+b > c) && (c+b > a) && (a+c > b)) ? printf(" valid T"): printf("invalid T");


}

