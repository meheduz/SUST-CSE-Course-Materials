/* find wheter number is multiuple of 2 or 5,but not both*/
#include<stdio.h>

void main(){

int n;

printf("enter a number");

scanf("%d",&n);

(((n%2==0) || (n%5==0)) && !((n%2==0) && (n%5==0))) ? printf("multiple of  2 or 5 but not both") : printf(" not a multiple of 2,5");

}


