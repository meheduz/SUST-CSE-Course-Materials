/* find wheter you are in loss or profit*/

#include<stdio.h>

void main(){

float buy,sell;
printf("enter buying and selling price: ");
scanf("%f%f",&buy,&sell);

(sell> buy) ? printf("Profit") : printf(" loss"); // (sell-buy > 0)


}

