/* find  area  of a scalene triangle or in general triangle*/

#include<stdio.h>
#include<math.h> // sqrt()   pow(base,power)
void main(){

float a,b,c,s,area;

printf("enter three sides of triangle: ");
scanf("%f%f%f",&a,&b,&c);

s = (a+b+c)/2;

area = sqrt(s * (s-a)* (s-b)* (s-c));

printf("desired area of the scalene triangle: %f",area);


}

