/* find wheter two matrix will be multiplicable or not, 
if it is then print the resultant dimension of ouput matrix*/

#include<stdio.h>

void main(){

int r1,c1,r2,c2;

printf("enter r1,c1,r2,c2");

scanf("%d%d%d%d",&r1,&c1,&r2,&c2);

(c1==r2) ? printf("output matrix multi: (%d,%d)",r1,c2) : printf("not multiplicable");

}

