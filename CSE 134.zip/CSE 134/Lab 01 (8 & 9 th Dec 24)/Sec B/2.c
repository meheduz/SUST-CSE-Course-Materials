/* printing area of a triangle with precison upto 2 digits */
#include<stdio.h>

void main(){

float h,w,area;

printf("enter height and width: ");

scanf("%f %f",&h,&w);

area = 0.5 * h * w;

printf("desired area of the triangle : %.2f",area);

}

