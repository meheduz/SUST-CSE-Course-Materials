/* find eucledian distance of two cartesian points*/
#include<stdio.h>
#include<math.h> // pow(x,n)  sqrt()
void main(){


int x1,y1,x2,y2;

printf("enter two cartesian points: ");

scanf("%d%d%d%d",&x1,&y1,&x2,&y2);

float ed =  sqrt(pow((x1-x2),2) + pow((y1-y2),2));

printf(" desired eucledian distance : %f",ed);
}

