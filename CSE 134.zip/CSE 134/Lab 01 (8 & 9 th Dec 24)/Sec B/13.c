/* find absolute difference between two number 
without using any special library*/ 

#include<stdio.h>
#include<stdlib.h> // abs()
void main(){

float x,y,d;

printf("ENTER two numbers: ");
scanf("%f%f",&x,&y);

//d = abs(x-y);

d = (x>y) ? (x-y) : (y-x);

printf("absolute difference is %f",d);
}

