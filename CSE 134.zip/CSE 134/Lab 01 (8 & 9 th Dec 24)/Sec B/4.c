/* find desired circumference, area and volume of a cyllinder using macro */
#include<stdio.h>
#define PI 3.1415978
void main(){

float r,h,a,c,v;
printf("enter radius and height: ");
scanf("%f%f",&r,&h);

c = 2 * PI * r * h;

a = 2 * PI * r *(r + h);

v = PI * r * r * h;

printf("desired circumference, area and volume : %.3f , %.3f , %.3f",c,a,v);

}
