/* convert seconds into hour: minutes:seconds */
#include<stdio.h>

void main(){

int n;
printf("enter seconds: ");
scanf("%d",&n);

int h,m,s;

h = n / 3600; // 1h = 3600 sec
int temp = n % 3600;

m = temp / 60; // 1 min = 60 sec

s = temp % 60;

printf("Clock : (%d : %d : %d)",h,m,s);





}

