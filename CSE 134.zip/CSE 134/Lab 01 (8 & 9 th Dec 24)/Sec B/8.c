/* find wheter you will be fined or not based on crossing the limit of acceleration of 5.5 m per sec squre*/
#include<stdio.h>

void main(){

float s,t,a;

printf("enter s and t: ");

scanf("%f%f",&s,&t);

a = s/(t*t);
printf("accelaration is %f\n",a);

(a > 5.5) ? printf("penalty"): printf("no problem, go!!!");



}
