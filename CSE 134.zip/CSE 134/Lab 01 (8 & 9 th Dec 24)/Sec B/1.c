/* printing a text using \n \t */
#include<stdio.h>

void main(){

printf("Welcome to\nCSE\t\tSUST");

}
