/* find desired circumference, area and volume of a cyllinder */

#include<stdio.h>

void main(){

float r,h,a,c,v;
printf("enter radius and height: ");
scanf("%f%f",&r,&h);

c = 2 * 3.1416 * r * h;

a = 2 * 3.1416 * r *(r + h);

v = 3.1416 * r * r * h;

printf("desired circumference, area and volume : %.3f , %.3f , %.3f",c,a,v);

}
