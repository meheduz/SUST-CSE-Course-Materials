/* find wheter a triplet (3 number pairs) is pythagorean or not i.e. a^2 = b^2 + c^2 */
#include<stdio.h>
#include<conio.h>
void main(){


int a,b,c;

printf(" enetr a,b,c (sides of a triangle");
scanf("%d%d%d",&a,&b,&c);

((a*a == b*b + c*c) || (b*b == a*a + c*c) || (c*c == b*b + a*a )) ? printf("pythagorean triplet"): printf("not a pythagorean triplet") ;


getch();
}


