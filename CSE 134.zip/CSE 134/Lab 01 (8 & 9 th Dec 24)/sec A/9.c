/* convert temperature from farenheit to celcius*/
#include<stdio.h>
#include<conio.h>
void main(){

float f,c;

printf("Enter temperature in farenheit: ");
scanf("%f",&f);

c= (f-32)*5/9;

printf(" temp in celcius: %f ",c);
getch();
}

