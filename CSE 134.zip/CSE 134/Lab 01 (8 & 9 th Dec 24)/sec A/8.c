/* find wheter a number positive or negative*/
#include<stdio.h>
#include<conio.h>
void main(){


int n;

scanf("%d",&n);

(n>=0) ? printf("non-negative"): printf("negative") ;


getch();
}
