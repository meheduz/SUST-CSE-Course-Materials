/* find wheter a triangle valid or invalid*/
#include<stdio.h>
#include<conio.h>
void main(){


int a,b,c;

printf(" enetr a,b,c (sides of a triangle");
scanf("%d%d%d",&a,&b,&c);

((a+b > c) && (b+c>a) && (c+a>b)) ? printf("valid t"): printf("invalid t") ;


getch();
}

