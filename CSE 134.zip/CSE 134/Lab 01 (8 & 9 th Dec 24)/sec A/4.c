/* find area & volume of the sphere using macro */

#include<stdio.h>
#include<conio.h>
#define PI 3.14159

void main(){

float radius,area,volume;

printf("Enter radius: ");

scanf("%f",&radius); /* input
is for circle
*/

area = 4 * PI * radius * radius;
//volume = 4 * PI * radius * radius * radius/3;
volume = 4.0/3 * PI * radius * radius * radius;
printf("Desired area and volume of the sphere : %f , %f",area,volume);


getch();
}
