/* find wheter a person is slim or fate based on BMI values */
#include<stdio.h>
#include<conio.h>
void main(){

float w,h;

printf("enter weight in kg : ");
scanf("%f",&w);

printf("enter height in m : ");
scanf("%f",&h);

float BMI = w/(h*h);

printf("bmi is %f\n",BMI);


(BMI >= 24.5) ? printf("mota masnush"): printf("chikon manush");
getch();
}
