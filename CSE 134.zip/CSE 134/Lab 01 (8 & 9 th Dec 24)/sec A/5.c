/* find Simple and Compound Interest */
#include<stdio.h>
#include<conio.h>
#include<math.h> // pow(base,power)

void main(){

float P,r,n,SI,CI;

printf("Enter P (in tk),n (in years),r (in %%)");
scanf("%f%f%f",&P,&n,&r);

SI = P * n* r/100;

printf("Desired Simple Interest is %f\n",SI);

CI = P * pow(1+r/100,n) - P;
printf("Desired Compound Interest is %f",CI);
getch();
}
