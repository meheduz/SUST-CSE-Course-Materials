/* find wheter a student passed or failed where average pass mark is 40*/
#include<stdio.h>
#include<conio.h>
void main(){

int m1,m2,m3;
float avg;
printf("enter phy,chem,math marks :");
scanf("%d%d%d",&m1,&m2,&m3);

avg = (m1+m2+m3)/3;

printf(" avg mark is %f",avg);

(avg >= 40) ? printf(" beche geso"): printf(" bari jao");

getch();
}
