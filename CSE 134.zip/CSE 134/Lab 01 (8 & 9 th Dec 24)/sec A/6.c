/* find root of a quadratic equation */
#include<stdio.h>
#include<conio.h>
#include<math.h> // sqrt()
void main(){

float a,b,c,D,x1,x2;

printf("Enter a,b,c (coefficeints of eqn: ");
scanf("%f%f%f",&a,&b,&c);

D = b*b - 4*a*c;

//(D<0) ? return :   ;

x1 = (-b + sqrt(D))/(2*a);
x2 = (-b - sqrt(D))/(2*a);


printf("1st : %f , 2nd : %f",x1,x2);
getch();
}
