/* printing a text using \n \t */

#include<stdio.h>
#include<conio.h>
void main(){

printf("Welcome to\nCSE\tSUST");
getch();
}
