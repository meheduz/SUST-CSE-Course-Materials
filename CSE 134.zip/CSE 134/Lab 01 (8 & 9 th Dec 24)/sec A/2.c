/* find area of the circle */
#include<stdio.h>
#include<conio.h>
void main(){

float radius,area;

printf("Enter radius: ");

scanf("%f",&radius); /* input
is for circle
*/

area = 3.1416 * radius * radius;

printf("Desired area of the circle : %f",area);

getch();
}
