/* find wheter a number even or odd*/
#include<stdio.h>
#include<conio.h>
void main(){


int n;

scanf("%d",&n);

(n%2==0) ? printf(" even"): printf("odd") ;


getch();
}
