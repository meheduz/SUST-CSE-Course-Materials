/*octal To Decimal Conversion */
#include<stdio.h>

int octalToDecimal(int octal){

int d,p=0,s=0;

while(octal!=0){

    d = octal % 10;
     s = s + d*pow(8,p);
     p++;
     octal/= 10;
}
return s;

}
void main(){

int octal;
scanf("%d",&octal);


printf("(%d)8 -> (%d)10",octal,octalToDecimal(octal));

}

