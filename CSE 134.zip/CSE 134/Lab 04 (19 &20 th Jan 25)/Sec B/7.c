/* print digits from MSD(Most Significant Digit)  TO LSD(Lowest Significant Digit) Using the technique of reversing the number*/
#include<stdio.h>

int reverseANumber(int n){

    int b = n,r;
    int s = 0;
    while(n!=0)
    {
        r = n % 10; /// 123 % 10 = 3   12%10 = 2
        s = s * 10 + r;
        //printf("%d,",r);
        n = n / 10; /// 123/10 = 12.3 -> 12
    }

    //printf("REVERSE OF %d is %d",b,s);

    return s;

}
void main()
{

    int n,r;

    scanf("%d",&n);
    int reverse = reverseANumber(n);
    n = reverse; /// 321
    printf("REVERSE OF %d is %d\n",n,reverse);
    while(n!=0)
    {
        r = n % 10; /// 321 % 10 = 1   32%10 = 2
        printf("%d,",r);
        n = n / 10; /// 123/10 = 12.3 -> 12
    }




}

