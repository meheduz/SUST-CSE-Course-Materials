/* conversion of lower to upper and vice & versa*/
#include<stdio.h>

int isAlphabet(char ch){

//(ch>='a' && ch <='z'|| ch>='A' && ch <='Z') ? 1: 0;

return (ch>='a' && ch <='z'|| ch>='A' && ch <='Z');
}

char convertLower(char ch){

   if(isAlphabet(ch)){
    if(ch>='A' && ch <='Z')
        return ch + 32;
    else return ch;
   }

}

char convertUpper(char ch){

   if(isAlphabet(ch)){
    if(ch>='a' && ch <='z')
        return ch - 32;
    else return ch;
   }

}

void main(){

char ch;
printf("Enter a character:");
scanf("%c",&ch);

int choice;
printf("Enter \n1 for UtoL:\n2 for LtoU ");
scanf("%d",&choice);

if(choice==1){
      char low = convertLower(ch);
      printf("LowerCase of %c : %c",ch,low);
}else{
      char up = convertUpper(ch);
      printf("UpperCase of %c : %c",ch,up);
}


}
