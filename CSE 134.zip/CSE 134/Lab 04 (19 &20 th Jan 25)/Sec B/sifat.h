void displayNumberInForward(int n){

    int c = 0,r;
    int b = n;
    while(n!=0)
    {
        r = n % 10;
        ///printf("%d,",r);
        n = n / 10;
        c++;
    }
    printf("Total Digits %d\n",c);
    n = b;
    int div = pow(10,c-1);

    while(n!=0)
    {

        r = n / div;
        printf("%d, ",r);
        n = n % div;
        div  = div/10;

    }


}