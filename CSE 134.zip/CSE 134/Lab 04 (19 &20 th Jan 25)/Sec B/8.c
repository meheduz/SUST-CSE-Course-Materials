/* Design pow(x,n) without using any special library  */
#include<stdio.h>

int my_pow(int x,int n){

int c = 0;
int m = 1;
while(c<n){

    m = m*x;;
    c++;
}

return m;

}
void main(){

int x,n;
scanf("%d%d",&x,&n);

printf("pow(%d,%d) == %d^%d == %d",x,n,x,n,my_pow(x,n));


}

