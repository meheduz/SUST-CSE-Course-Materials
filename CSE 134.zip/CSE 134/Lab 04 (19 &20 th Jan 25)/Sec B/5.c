/* print digits from MSD(Most Significant Digit)  TO LSD(Lowest Significant Digit) */
#include<stdio.h>
#include<math.h>
#include"sifat.h"

void main()
{
    int n,r;
    scanf("%d",&n); /// 123456

    displayNumberInForward(n);

}
