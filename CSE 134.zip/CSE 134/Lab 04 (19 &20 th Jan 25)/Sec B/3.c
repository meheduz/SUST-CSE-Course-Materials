/* decimal To Octal conversion */
#include<stdio.h>

int decimalToOctal(int n)
{
    int m = 1,s=0,r;
    while(n!=0)
    {
        r = n%8;
        s += r*m;
        n/= 8;
        m*= 10;
    }
    return s;
}

void main(){

int n;
scanf("%d",&n);
int res = decimalToOctal(n);
printf("(%d)10 -> (%d)8",n,res);


}


