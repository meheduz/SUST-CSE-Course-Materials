/* Identify the proper quadrant given (x,y) co-ordinates */
#include<stdio.h>


int quadrantFinder(int x,int y){
int quadrant;
if(x>0 && y > 0) quadrant=1;
else if(x<0 && y > 0) quadrant=2;
else if(x<0 && y < 0) quadrant=3;
else if(x>0 && y < 0) quadrant=4;
else quadrant=-1;


return quadrant;
}
void main(){

int x,y;

printf("Enter x,y:");
scanf("%d%d",&x,&y);
int quad = quadrantFinder(x,y);
char* suf;
if (quad==1)  suf= "st";
else if (quad==2)  suf= "nd";
else if (quad==3)  suf= "rd";
else if (quad==4)  suf= "th";
else suf="";

printf("(%d,%d) point lies in %d%s Quadrant",x,y,quad,suf);

}



