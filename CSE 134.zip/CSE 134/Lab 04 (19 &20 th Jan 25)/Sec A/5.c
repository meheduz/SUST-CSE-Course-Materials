/*display upper, lower and numbers */
#include<stdio.h>

void displayUpperCaseLetters(){

int i = 65;

while(i<=90){

 printf("%c -> (%d)\n",i,i);
 i++;
}

}

void displayLowerCaseLetters(){

int i = 97;

while(i<=122){

 printf("%c -> (%d)\n",i,i);
 i++;
}

}

void displayNumbers(){

int i = 48;

while(i<57){

 printf("%c -> (%d)\n",i,i);
 i++;
}

}



void main(){

displayUpperCaseLetters();
printf("\n\n");
displayLowerCaseLetters();
printf("\n\n");
displayNumbers();

}
