/*Given two operands and an operator , do necessary calculation  */
#include<stdio.h>


float calculator(float op1,float op2,char opr){

    float a=op1,b= op2;
    float result;
    if(opr=='+') result = a + b;  /// printf("%f %c %f = %f",a,opr,b,a+b);
    else if(opr =='-') result = a - b; /// printf("%f %c %f = %f",a,opr,b,a-b);
    else if(opr =='*') result = a * b;
    else if(opr =='/') result = a / b;
    else if(opr =='%') result = (int)a % (int)b;
    else printf(" unknown operator!!");

    return result;
}
void main()
{

    float a,b;
    char opr;

    printf("Enter Operator:");
    scanf("%c",&opr); /// + - / * %


    printf("Enter 1st and 2nd operands:");
    scanf("%f%f",&a,&b);

    float result = calculator(a,b,opr);

    printf("%f %c %f = %f",a,opr,b,result);
}

