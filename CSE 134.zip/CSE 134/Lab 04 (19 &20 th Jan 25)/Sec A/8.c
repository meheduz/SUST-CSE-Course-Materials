/*series generation of those numbers which are divisible by 5 & 7 both */
#include<stdio.h>

void main(){


int s,e;
scanf("%d%d",&s,&e);

int i = s;
while(i<=e){

    if(i%5==0 && i%7==0 )
      printf("%d\n",i);

     i++;
}
}


