/*series generation */
#include<stdio.h>
void main()
{
/// 18, -27, 36, -45, 54,   ....... ,-63
    int i = 18;
    while(i<=63)
    {
        if(i%2==1)
            printf("%d",-i);
        else printf("%d ",i);

        if(i!=63)
            printf(",");

        i+= 9;

    }

}
