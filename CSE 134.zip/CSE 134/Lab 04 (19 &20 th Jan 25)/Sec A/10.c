/* maximum and minimum marks finder */
#include<stdio.h>

void main(){
int n;
int max = -1,min = 101;
int c= 1;
do{

    printf("Enter Next mark:");
    scanf("%d",&n);
    if(n==101 || n == -1) break;
    if (n>max) max = n;
    printf("Current Highest: %d after %dth students\n",max,c);

    if (n<min) min = n;
    printf("Current Lowest: %d after %dth students\n",min,c);
    c++;


}while(1);




}



