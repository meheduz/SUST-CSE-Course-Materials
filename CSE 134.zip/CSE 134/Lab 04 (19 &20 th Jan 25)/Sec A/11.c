/*series generation of those numbers which are divisible by 5 or 7 but not both */
#include<stdio.h>

void main(){


unsigned int s,e;
printf("Enter the range (start,end)");
scanf("%d%d",&s,&e);

int i = s;
while(i<=e){

    if( i%5==0 && i%7!=0 ||
        i%5!=0 && i%7==0)
      printf("%d\n",i);

     i++;
}

}




