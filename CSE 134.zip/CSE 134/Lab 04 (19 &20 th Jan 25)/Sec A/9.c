/*Arithmatic series generation */
#include<stdio.h>

void displayArithmaticSeries(int a,int d,int n){

int i = a;
int c = 0;
while(c<n){

    if(c==n-1)
      printf("%d",i);
    else printf("%d,",i);
    i += d;
    c++;
}
}


void main(){

int a,n,d;

printf("Enter 1st term,difference and number of terms you want:");
scanf("%d%d%d",&a,&d,&n);

displayArithmaticSeries(a,d,n);
printf("\n\n");
displayArithmaticSeries(5,3,10);
printf("\n\n");
displayArithmaticSeries(5,4,10);


}



