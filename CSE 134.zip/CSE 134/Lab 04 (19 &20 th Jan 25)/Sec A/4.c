/*binary to decimal conversion*/
#include<stdio.h>

int binaryToDecimalConverter(int);

void main()
{

    int n;
    printf("enter a number in Binary:");
    scanf("%d",&n);

    int result = binaryToDecimalConverter(n);

    printf("(%d)2 => (%d)10",n,sum);

}

int binaryToDecimalConverter(int)
{
    int r,sum=0;
    int power = 0;
    while(n!=0)
    {
        r = n % 10;  /// LSB()1  0 1    0 1 1 MSB()
        //printf("%d",r);
        sum = sum + (r * pow(2,power)) ;
        n = n / 10; /// 45/2 = 22.5 = 22
        power += 1;
    }
    return sum;
}

