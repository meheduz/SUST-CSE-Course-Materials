/*decimal to binary conversion*/
#include<stdio.h>
void main(){

int n;
printf("enter a number in decimal:");
scanf("%d",&n);

int r;
int sum= 0;
int mult = 1;
while(n!=0){

    r = n % 2;  /// LSB()1  0 1    0 1 1 MSB()
    printf("%d",r);
    sum = r * mult + sum;
    n = n / 2; /// 45/2 = 22.5 = 22
    mult *= 10;
}
printf("\n%d",sum);

}
