/*decimal to binary conversion*/
#include<stdio.h>

int decToBinaryConverter(int);

void main()
{

    int n;
    printf("enter a number in decimal:");
    scanf("%d",&n);

    int result = decToBinaryConverter(n);
    printf("(%d)10 => (%d)2",n,result);

}

int decToBinaryConverter(int dec)
{
    int r;
    int sum= 0;
    int mult = 1;
    while(dec!=0)
    {

        r = dec % 2;  /// LSB()1  0 1    0 1 1 MSB()
        printf("%d",r);
        sum = r * mult + sum;
        dec = dec / 2; /// 45/2 = 22.5 = 22
        mult *= 10;
    }
///printf("\n%d",sum);
    return sum;

}
