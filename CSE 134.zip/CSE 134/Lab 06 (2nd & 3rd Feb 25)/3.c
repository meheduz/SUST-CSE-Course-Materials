/*alternating characterset printing Upper to lower and vice &versa with spaces*/
#include<stdio.h>
#include<string.h>

void main()
{

    char mstr[100],chgstr[100];///  pYt     hon fds dfvdf - > PyT     hOn     FdS d
    scanf("%[^\n]",mstr);

    int n = strlen(mstr);
    int c = 0;
    for(int i= 0; i<n; i++)
    {
        char ch = mstr[i];

        if(ch == ' ')
            chgstr[i] = ch;
        else
        {
            if(c%2==0)
            {
                if(ch >= 'a' && ch <= 'z')
                    chgstr[i] = ch -32; /// a 97 -32= 65 -> A
                else
                    chgstr[i] = ch;
            }
            else
            {

                if(ch >= 'A' && ch <= 'Z')
                    chgstr[i] = ch + 32; /// A 65 +32= 97 -> a
                else
                    chgstr[i] = ch;
            }
            c++;
        }


    }

    printf("Changed String is %s",chgstr);
}

