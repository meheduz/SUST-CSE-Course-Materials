/*string mixer*/
#include<stdio.h>
#include<string.h>


void main(){


char str1[100],str2[100],chgstr[200]; /// abcd  pqrstu -> apbqcrds tu  :  abcdef  pqr -> apbqcrdef

scanf("%[^\n]",str1);
getchar();
scanf("%[^\n]",str2);
getchar();
int l1 = strlen(str1);
int l2 = strlen(str2);
int mnlen = l1 > l2 ? l2:l1; /// min() max()
int mxlen = l1 > l2 ? l1:l2; /// min() max()
int c =0;

for(int i = 0;i<mnlen;i++){

    chgstr[c++] = str1[i]; /// 0 - 1
    chgstr[c++] = str2[i];/// 1 - 2
}
if(l1>l2){

   for(int j = mnlen;j< mxlen;j++ )
    chgstr[c++] = str1[j];

}else {
  for(int j = mnlen;j< mxlen;j++ )
    chgstr[c++] = str2[j];
}
chgstr[c] = '\0';

printf("Changed String: %s",chgstr);
}
