/*binary, octal, hexadecimal number checker*/
#include<stdio.h>
#include<string.h>/// strlen()

int binaryCheck(char *bin){

int l= strlen(bin); /// 1011110

int flag = 1;
for(int i = 0;bin[i] !='\0';i++){  /// for(int i = 0;i<l;i++)

    if(bin[i]!='0' && bin[i]!='1'){
        flag = 0;
        ///printf("%d\n",i); /// debugging
        break;
    }
}

return flag;
}

int octalCheck(char *oct){

int l= strlen(oct); /// 1011110

int flag = 1;
for(int i = 0;i<l;i++){

    if(oct[i] < '0' || oct[i] > '7'){
        flag = 0;
        ///printf("%d\n",i); /// debugging
        break;
    }
}


return flag;
}

int hexaDecimalCheck(char *hexa){

int l= strlen(hexa); /// 10A11E110

int flag = 1;
for(int i = 0;i<l;i++){
    ///if(hexa[i] < '0' || (hexa[i] < 'A || hexa[i] > 'F') || (hexa[i] < 'a' || hexa[i] > 'f') ){
    if((hexa[i] >= 65 && hexa[i] <= 70) || (hexa[i] >= 97 && hexa[i] <= 102) || (hexa[i] >= '0' && hexa[i] <= '9'))
       continue;
    else
    {
        flag = 0;
        ///printf("%d\n",i); /// debugging
        break;
    }
}

return flag;
}


void main(){

//char binaryN[15];
//scanf("%s",binaryN);

//printf("is %s Binary: %s?",binaryN,(binaryCheck(binaryN)>0) ? "Yes" : "No");


//char octalN[15];
//scanf("%s",octalN);

//printf("is %s Octal: %s?",octalN,(octalCheck(octalN)>0) ? "Yes" : "No");

char hexaN[15];
scanf("%s",hexaN);

printf("is %s hexaDecimal: %s?",hexaN,(hexaDecimalCheck(hexaN)>0) ? "Yes" : "No");
}

