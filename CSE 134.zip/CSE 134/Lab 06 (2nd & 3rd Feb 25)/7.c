/*sub-string finder*/
#include<stdio.h>

void main(){


char mstr[100],sstr[100];

scanf("%[^\n]",mstr);
getchar();
scanf("%[^\n]",sstr);
getchar();

for(int i = 0;i<strlen(mstr);i++){
    int j;
    for(j = 0;j<strlen(sstr);j++){/// coldtion breaking

        if(sstr[j] != mstr[i+j]){
            break; /// didn;t match
        }

    }

    if(j == strlen(sstr))
       {
           printf("Yes got it in index from : %d to %d\n",i+1,i+j);
           ///break;
       }
}





}
