/*alternating characterset printing Upper to lower and vice &versa*/
#include<stdio.h>
#include<string.h>

void main(){

char mstr[100],chgstr[100];///  pYthon - > PyThOn
scanf("%s",mstr);

int n = strlen(mstr);
for(int i= 0;i<n;i++){
     char ch = mstr[i];
    if(i%2==0){
        if(ch >= 'a' && ch <= 'z')
            chgstr[i] = ch -32; /// a 97 -32= 65 -> A
        else
            chgstr[i] = ch;
        }else{

        if(ch >= 'A' && ch <= 'Z')
            chgstr[i] = ch + 32; /// A 65 +32= 97 -> a
        else
            chgstr[i] = ch;
        }

}

printf("Changed String is %s",chgstr);
}
