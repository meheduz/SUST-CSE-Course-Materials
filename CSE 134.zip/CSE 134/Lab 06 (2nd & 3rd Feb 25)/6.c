/*palindromic string checker*/
#include<stdio.h>

void main(){

char str1[100];

scanf("%s",str1);  /// madam  ab  ba   am mu  abcdba

int l = strlen(str1);
int flag = 1;
for(int i = 0;i<(l/2);i++){

    if(str1[i]  != str1[l-1-i]){
        flag = 0;
        break;
    }
}

printf("Palindrome? %s",flag==1? "Yes": "No");

}
