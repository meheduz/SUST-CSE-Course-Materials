/*Another alternative solution: alternating characterset printing Upper to lower and vice &versa with spaces*/
#include<stdio.h>
#include<string.h>

void main()
{

    char mstr[100],chgstr[100];///  pYt     hon fds dfvdf - > PyT     hOn     FdS d
    scanf("%[^\n]",mstr);

    int n = strlen(mstr);
    chgstr[0] =  (mstr[0] >= 'a' && mstr[0] <= 'z')?  mstr[0] -32 : mstr[0];
    char status = 'U'; /// U-> UPPER AND L-> Lower

    for(int i= 1; i<n; i++)
    {
        char ch = mstr[i];

        if(ch == ' ')
            chgstr[i] = ch;
        else
        {
            if(status == 'U') /// old char-> status
            {
                if(ch >= 'A' && ch <= 'Z')
                    chgstr[i] = ch + 32; /// A 65 +32= 97 -> a
                else
                    chgstr[i] = ch;

              status = 'L';
            }
            else /// old char-> status
            {
                if(ch >= 'a' && ch <= 'z')
                    chgstr[i] = ch -32; /// a 97 -32= 65 -> A
                else
                    chgstr[i] = ch;
             status = 'U';
            }
        }


    }

    printf("Changed String is %s",chgstr);
}


