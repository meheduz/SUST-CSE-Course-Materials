/* Menu Driven (Choice Based) Area Finder Program*/
#include<stdio.h>
#include<math.h>
void main()
{

    int choice;

    while(1)
    {



        printf("1. Circle\n");
        printf("2. Sphere\n");
        printf("3. Square\n");
        printf("4. Triangle\n");
        printf("5. Exit\n");
        scanf("%d",&choice);

///if(choice==5) break;

        if(!(choice==1 || choice==2 ||choice==3 ||choice==4))
            break;

        float rad;
        switch(choice)
        {

        case 1:
            printf("Enter Radius:");
            scanf("%f",&rad);
            printf("Area is %f",M_PI*rad*rad);
            break;
        case 2:
            printf("Enter Radius:");
            scanf("%f",&rad);
            printf("Area is %f",4*M_PI*rad*rad);
            break;
        case 3:
            printf("Enter Side:");
            float side;
            scanf("%f",&side);
            printf("Area is %f",side*side);
            break;
        case 4:
            printf("Enter H & W:");
            float h,w;
            scanf("%f%f",&h,&w);
            printf("Area is %f",0.5*h*w);
            break;
        default:
            printf("Wrong Choice!");
        }

        printf("\n\n");

    }

}


