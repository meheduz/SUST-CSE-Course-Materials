/* Print Fibonacci Series given the first two numbers, also the limit(nearest small number to the last term of the series) */
#include<stdio.h>

void main(){

int n0,n1,n2,limit;
scanf("%d%d",&n0,&n1); ///  0 1 1 2 3 5   5 6 11 17
scanf("%d",&limit);
printf("%d %d ",n0,n1);
while(1){
    n2 = n1 + n0;

    if(n2>limit)
        break;

    printf("%d ",n2);
    n0 = n1;
    n1 = n2;
};


}
///  0(n0) 1(n1) 1(n2) 2 3 5   5 6 11 17
///  0 1(n0) 1(n1) 2(n2) 3 5   5 6 11 17


