/* Design pow(x,n) without using any special library  */
#include<stdio.h>

void main(){

int x,n;
scanf("%d%d",&x,&n);
int c = 0;
int m = 1;
while(c<=n){

    m = m*x;;
    c++;
}
printf("pow(%d,%d) == %d^%d == %d",x,n,x,n,m);
}

