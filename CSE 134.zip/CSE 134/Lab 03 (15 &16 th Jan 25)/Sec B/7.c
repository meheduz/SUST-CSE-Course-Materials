/* Printing Multiplication Table given a number */
#include<stdio.h>

void main()
{

    int n;
    scanf("%d",&n);
    int i = 1;
    while(i<11)
    {

        printf("%d x %d = %d\n",n,i,n*i);
        i++;

    }

}

