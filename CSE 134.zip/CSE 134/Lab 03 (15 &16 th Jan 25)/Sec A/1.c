/*Given two operands and an operator , do necessary calculation  */
#include<stdio.h>

void main()
{

    float a,b;
    char opr;

    printf("Enter Operator:");
    scanf("%c",&opr); /// + - / * %


    printf("Enter 1st and 2nd operands:");
    scanf("%f%f",&a,&b);

    float result;
    if(opr=='+') result = a + b;  /// printf("%f %c %f = %f",a,opr,b,a+b);
    else if(opr =='-') result = a - b; /// printf("%f %c %f = %f",a,opr,b,a-b);
    else if(opr =='*') result = a * b;
    else if(opr =='/') result = a / b;
    else if(opr =='%') result = (int)a % (int)b;
    else printf(" unknown operator!!");

    printf("%f %c %f = %f",a,opr,b,result);
}

