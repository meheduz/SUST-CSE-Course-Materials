/* find average marks for some given marks until a negative mark entered */
#include<stdio.h>

void main(){

int mark,c = 0;
int sum = 0;
while(1){

    printf("Enter Mark:");
    scanf("%d",&mark);

    if(mark<0) break;
    else sum += mark;
    c++;

}

printf("Average is %f",sum*1.0/c);

}


