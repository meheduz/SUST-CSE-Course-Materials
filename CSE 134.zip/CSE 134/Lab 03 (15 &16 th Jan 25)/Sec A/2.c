/* Check whether a number is palindromic or not like 121 14641 are palindromic but 123 498 are not*/
#include<stdio.h>

void main()
{

    int n,r;

    scanf("%d",&n);
    int b = n;
    int s = 0;
    while(n!=0)
    {
        r = n % 10; /// 123 % 10 = 3   12%10 = 2
        s = s * 10 + r;
        printf("%d,",r);
        n = n / 10; /// 123/10 = 12.3 -> 12
    }

  printf("REVERSE OF %d is %d",b,s);

 if(b==s) printf("PALINDROMIC NUMBER");
 else printf("Not a Palindromic number");

}

