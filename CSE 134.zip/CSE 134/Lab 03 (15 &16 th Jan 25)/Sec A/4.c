/* find gcd and lcm of two numbers*/
#include<stdio.h>

void main()
{

    int a,b;
    scanf("%d%d",&a,&b);

    int small = (a>b) ? b:a;
    int gcd = 1;


    int i = 1;
    while(i<=small){

        if (a%i== 0 && b%i==0)
            gcd = i;

        i++;
    }

    printf("GCD OF %d and %d is %d",a,b,gcd);
    printf("\nLCM OF %d and %d is %d",a,b,a*b/gcd);
}

