/* Authenticating the user with pin to let them allow into the server*/
#include<stdio.h>

void main(){

int pin,pass = 1234;
do{
    printf("Enter Pin:");
    scanf("%d",&pin);

    if(pin==pass) break;


}while(1);


printf("You have entered into the server");


}

