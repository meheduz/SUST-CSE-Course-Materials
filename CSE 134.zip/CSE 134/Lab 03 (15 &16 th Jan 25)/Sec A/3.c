/* find out whether a number is armstrong or not. (An Armstrong number is a number that is equal
                                                   to the sum of its digits, each raised to the
                                                   power of the number of digits in the number.
                                                   For example, 153 is an Armstrong number because
                                                   (1^{3}+5^{3}+3^{3}=153).)
*/
#include<stdio.h>
#include<math.h>
void main()
{

    int n,r;
    int c = 0;
    scanf("%d",&n);

    int b = n;
    while(n!=0)
    {
        r = n % 10; /// 123 % 10 = 3   12%10 = 2
        printf("%d,",r);
        n = n / 10; /// 123/10 = 12.3 -> 12
        c++;
    }

    printf("\nTotal digits %d",c);
    n = b;
    int sum = 0;
     while(n!=0)
    {
        r = n % 10; /// 123 % 10 = 3   12%10 = 2
        sum = sum + pow(r,c);
        printf("current sum %d when remainder is %d\n",sum,r);
        n = n / 10; /// 123/10 = 12.3 -> 12
    }

    printf("Sum is %d",sum);

    if(sum== b)  printf("Armstrong");
    else printf("Sorry ! ArmWeak");


}

