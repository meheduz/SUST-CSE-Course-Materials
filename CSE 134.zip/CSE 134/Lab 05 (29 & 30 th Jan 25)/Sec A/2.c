/* Checking Symmetric or ASymmetric matrix with prefixed dimension */
#include<stdio.h>

void main(){

int a[3][3];
printf("First Matrix:");
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
        scanf("%d",&a[i][j]);
}
int flag = 1;
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
       if(a[i][j]!=a[j][i]){
        flag = 0;
        break;
       }
}

flag? printf("Symmetric") : printf("Asymmetric");

}
