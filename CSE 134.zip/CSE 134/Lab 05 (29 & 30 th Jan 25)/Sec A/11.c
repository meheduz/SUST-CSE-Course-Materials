/*Insertion of a item from matrix with given dimension */
#include<stdio.h>

void main(){

int n;
printf("Enter Dimension of extended matrix:");
scanf("%d",&n);

int a[n],p,x;

int i;
printf("First Matrix:");
for(i = 0;i<=(n-2);i++)
    scanf("%d",&a[i]);

printf("\nPosition:");
 scanf("%d",&p);
printf("\nElement:");
scanf("%d",&x);




while(p<=0 || p>(n-1)){
     printf("Enter valid input Again");
     scanf("%d",&p);

}

for(i = (n-1);i>=p;i--)
    a[i] = a[i-1];

a[p-1] = x;

printf("Changed Matrix:");
for(i = 0;i<=(n-1);i++)
    printf("%d ",a[i]);

}

