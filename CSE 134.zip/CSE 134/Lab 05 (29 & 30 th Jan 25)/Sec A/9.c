/* merging two 1D matrices into One with given dimension  */
#include<stdio.h>

void main(){

printf("Enter First Matrix Dimesion");
scanf("%d",&d1);

printf("Enter Second Matrix Dimesion");
scanf("%d",&d2);

int a[d1],b[d2],c[d1+d2];

printf("First Matrix:");
for(int i = 0;i<d1;i++)
    scanf("%d",&a[i]);

printf("Second Matrix:");
for(int i = 0;i<d2;i++)
    scanf("%d",&b[i]);


for(int i = 0;i<(d1+d2);i++)
    if(i<d1) c[i] = a[i];
    else c[i] = b[i-d1];

printf("Merged Matrix:");
for(int i = 0;i<(d1+d2);i++)
    printf("%d ",c[i]);

}
