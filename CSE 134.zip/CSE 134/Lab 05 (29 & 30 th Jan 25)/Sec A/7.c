/* addition or subtraction of two matrices given the dimension */
#include<stdio.h>

void main(){

int r,c;
printf("Enter The dimension: row and column");
scanf("%d%d",&r,&c);

int a[r][c],b[r][c],c[r][c],d[r][c];
printf("First Matrix:");
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        scanf("%d",&a[i][j]);
}

printf("Second Matrix:");
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        scanf("%d",&b[i][j]);
}
/// addition or subtraction
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++){
        c[i][j]= a[i][j] + b[i][j];
        d[i][j]= a[i][j] - b[i][j];
    }

}

printf("addition\n");
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        printf("%d ",c[i][j]);
    printf("\n");
}
printf("subtraction\n");
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        printf("%d ",d[i][j]);
    printf("\n");
}


}
