/*Deletion of a item from matrix with fixed size matrix */
#include<stdio.h>

void main(){

int a[7],p;

printf("First Matrix:");
for(int i = 0;i<7;i++)
    scanf("%d",&a[i]);

printf("Enter Position of the item you want to delete");
scanf("%d",&p);

// if(p>0 && p<=7){

//   for(int i = p-1;i<6;i++)
//     a[i] = a[i+1];

// printf("Changed Matrix:");
// for(int i = 0;i<6;i++)
//     printf("%d ",a[i]);

// }
// else printf("Invalid Location");



while(p<=0 || p>7){
     printf("Enter valid input Again");
     scanf("%d",&p);

}

 for(int i = p-1;i<6;i++)
    a[i] = a[i+1];

printf("Changed Matrix:");
for(int i = 0;i<6;i++)
    printf("%d ",a[i]);

}

