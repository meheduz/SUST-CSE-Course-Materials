/* Checking Symmetric or ASymmetric matrix with given dimension */
#include<stdio.h>

void main(){

int n;
printf("Enter Dimension: row/column");
scanf("%d",&n);

int a[n][n];

printf("First Matrix:");
for(int i = 0;i<n;i++){
    for(int j= 0;j<n;j++)
        scanf("%d",&a[i][j]);
}
int flag = 1;
for(int i = 0;i<n;i++){
    for(int j= 0;j<n;j++)
       if(a[i][j]!=a[j][i]){
        flag = 0;
        break;
       }
}

flag? printf("Symmetric") : printf("Asymmetric");

}
