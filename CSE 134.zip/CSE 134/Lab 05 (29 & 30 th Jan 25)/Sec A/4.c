/* merging two 1D matrices into One with prefixed dimension  */
#include<stdio.h>

void main(){

int a[4],b[6],c[10];

printf("First Matrix:");
for(int i = 0;i<4;i++)
    scanf("%d",&a[i]);

printf("Second Matrix:");
for(int i = 0;i<6;i++)
    scanf("%d",&b[i]);


for(int i = 0;i<10;i++)
    if(i<4) c[i] = a[i];
    else c[i] = b[i-4];

printf("Merged Matrix:");
for(int i = 0;i<10;i++)
    printf("%d ",c[i]);

}
