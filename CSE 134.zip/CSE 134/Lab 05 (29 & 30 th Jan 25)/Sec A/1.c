/* addition or subtraction of two matrices of predefined dimension */
#include<stdio.h>

void main(){

int a[3][3],b[3][3],c[3][3],d[3][3];
printf("First Matrix:");
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
        scanf("%d",&a[i][j]);
}

printf("Second Matrix:");
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
        scanf("%d",&b[i][j]);
}
/// addition or subtraction
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++){
        c[i][j]= a[i][j] + b[i][j];
        d[i][j]= a[i][j] - b[i][j];
    }

}

printf("addition\n");
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
        printf("%d ",c[i][j]);
    printf("\n");
}
printf("subtraction\n");
for(int i = 0;i<3;i++){
    for(int j= 0;j<3;j++)
        printf("%d ",d[i][j]);
    printf("\n");
}


}
