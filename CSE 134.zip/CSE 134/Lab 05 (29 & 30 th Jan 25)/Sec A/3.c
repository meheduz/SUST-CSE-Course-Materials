/* Checking Sparseor Non-Sparse matrix with given dimension */
#include<stdio.h>

void main(){
int r,c;
printf("Enter The dimension: row and column");
scanf("%d%d",&r,&c);

int a[r][c];
printf("First Matrix:");
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        scanf("%d",&a[i][j]);
}
int z =0,nz=0;
for(int i = 0;i<r;i++){
    for(int j= 0;j<c;j++)
        if(a[i][j]!=0) nz++;
        else z++;
}
(nz>z) ? printf("Non-Sparse"): printf("Sparse");

}
