/*Insertion of a item from matrix with fixed size matrix */
#include<stdio.h>

void main(){

int a[8],p,n;

int i;
printf("First Matrix:");
for(i = 0;i<=6;i++)
    scanf("%d",&a[i]);

printf("\nPosition:");
 scanf("%d",&p);
printf("\nElement:");
 scanf("%d",&n);




while(p<=0 || p>7){
     printf("Enter valid input Again");
     scanf("%d",&p);

}

for(i = 7;i>=p;i--)
    a[i] = a[i-1];

a[p-1] = n;

printf("Changed Matrix:");
for(i = 0;i<=7;i++)
    printf("%d ",a[i]);

}

