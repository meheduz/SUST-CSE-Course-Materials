/*Deletion of a item from matrix with dynamic size matrix */
#include<stdio.h>

void main(){

int n;
printf("Enter Dimension");
scanf("%d",&n);

int a[n],p;

printf("First Matrix:");
for(int i = 0;i<n;i++)
    scanf("%d",&a[i]);

printf("Enter Position of the item you want to delete");
scanf("%d",&p);

// if(p>0 && p<=n){

//   for(int i = p-1;i<(n-1);i++)
//     a[i] = a[i+1];

// printf("Changed Matrix:");
// for(int i = 0;i<(n-1);i++)
//     printf("%d ",a[i]);

// }
// else printf("Invalid Location");



while(p<=0 || p>n){
     printf("Enter valid input Again");
     scanf("%d",&p);

}

 for(int i = p-1;i<n-1;i++)
    a[i] = a[i+1];

printf("Changed Matrix:");
for(int i = 0;i<(n-1);i++)
    printf("%d ",a[i]);

}

