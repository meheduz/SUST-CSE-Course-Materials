/*find out first,second maximum number from an array of numbers */
#include<stdio.h>

void main(){

int n;
printf("Enter dimension:");
 scanf("%d",&n);

int a[n]; /// a[5];

for(int i= 0;i<n;i++)
    scanf("%d",&a[i]);

int max=a[0],mi,secmax=a[0],smi;
for(int i= 1;i<n;i++){

    if(max<a[i]){
        secmax = max;
        smi = mi;

        max = a[i];
        mi = i+1;
    }else if (a[i] >secmax){

        secmax = a[i];
        smi = i+1;
    }

}

printf("Max Marks: %d got by %d",max,mi);

printf("\n Second Max Marks: %d got by %d",secmax,smi);


}
