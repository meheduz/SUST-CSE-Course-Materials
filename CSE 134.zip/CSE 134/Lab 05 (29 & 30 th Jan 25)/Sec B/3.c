/*find out Traces from Primary and Secondary Diagonals of a 2D matrix */
#include<stdio.h>

void main(){
int r,c;


do{
 printf("Enter dimension: row and column");
 scanf("%d%d",&r,&c);
}while(r!=c);

int a[r][c]; /// a[5][5];
for(int i= 0;i<r;i++)
    for(int j=0;j<c;j++)
        scanf("%d",&a[i][j]);

int Ptrace = 0;
for(int i= 0;i<r;i++)
    Ptrace+= a[i][i];

printf("Trace(Primary Diagonal): %d",Ptrace);

int Strace = 0;
for(int i= 0;i<r;i++)
    Strace+= a[i][r-1-i];

printf("Trace(Secondary Diagonal): %d",Strace);

}

