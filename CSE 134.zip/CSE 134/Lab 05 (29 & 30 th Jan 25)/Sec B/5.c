/*find out upper and lower Triangular matrix of a 2D matrix */
#include<stdio.h>

void main(){
int r,c;

 printf("Enter dimension: row and column");
 scanf("%d%d",&r,&c);


int a[r][c]; /// a[5][5];
for(int i= 0;i<r;i++)
    for(int j=0;j<c;j++)
        scanf("%d",&a[i][j]);

printf("\nUpper Triangular Matrix:\n")
for(int i= 0;i<r;i++){

    for(int j=0;j<i;j++)
        printf("0 ");

    for(int j=i;j<c;j++)
        printf("%d ",a[i][j]);
    printf("\n");
}

printf("\nLower Triangular Matrix:\n")
for(int i= 0;i<r;i++){


    for(int j=0;j<=i;j++)
        printf("%d ",a[i][j]);

    for(int j=1;j<=c-1-i;j++)
        printf("0 ");
    printf("\n");
}





}
