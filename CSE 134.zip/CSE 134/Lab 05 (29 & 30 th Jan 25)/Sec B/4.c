/*find out row_sum and column_sum of a 2D matrix */
#include<stdio.h>

void main(){
int r,c;

 printf("Enter dimension: row and column");
 scanf("%d%d",&r,&c);


int a[r][c]; /// a[5][5];
for(int i= 0;i<r;i++)
    for(int j=0;j<c;j++)
        scanf("%d",&a[i][j]);

for(int i= 0;i<r;i++){

    int sum= 0;
    for(int j=0;j<c;j++)
        sum+= a[i][j];
    printf("Sum of %d row: %d\n",(i+1),sum);

}



for(int j= 0;j<c;j++){

   int sum= 0;
    for(int i=0;i<r;i++)
        sum += a[i][j];
    printf("Sum of %d Col: %d\n",(j+1),sum);
}

}
