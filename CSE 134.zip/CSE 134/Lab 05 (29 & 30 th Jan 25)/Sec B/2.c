/*find out first,second and third maximum number from an array of numbers */
#include<stdio.h>

void main(){

int n;
printf("Enter dimension:");
 scanf("%d",&n);

int a[n]; /// a[5];

for(int i= 0;i<n;i++)
    scanf("%d",&a[i]);

int max=a[0],mi,secmax=a[0],smi,thirdmax=a[0],tmi;
for(int i= 1;i<n;i++){

    if(max<a[i]){
        thirdmax = secmax;
        tmi = smi;

        secmax = max;
        smi = mi;

        max = a[i];
        mi = i+1;
    }else if (a[i] >secmax){
        thirdmax = secmax;
        tmi = smi;

        secmax = a[i];
        smi = i+1;
    }else if(a[i]>thirdmax){
      thirdmax = a[i];
      tmi = i+1;
    }

}

printf("Max Marks: %d got by %d",max,mi);

printf("\n Second Max Marks: %d got by %d",secmax,smi);

printf("\n Third Max Marks: %d got by %d",thirdmax,tmi);
}
